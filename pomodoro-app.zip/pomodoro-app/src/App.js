import logo from './logo.svg';
import './App.css';
import React from 'react';
import FocusTimer from './pages/FocusTimer';


function App() {
  return (
    <div className="App">
      <div className='App-header'>
        <h1>Focus & Task Manager</h1>
        <FocusTimer />
      </div>
    </div>
  );
}

export default App;
