import React from 'react';

function generateImage()    {
    return (
        <>
            <div style={{
                backgroundImage: `url(/img/image.jpg)`
            }}></div>
        </>
    );
}

export default generateImage;