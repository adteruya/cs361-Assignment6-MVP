import React from 'react';

class TimerClass extends React.Component {
    constructor()   {
        super();
        this.state = { display : {}, time: 1500000 };
        this.status = "default";
        this.statusID = 0;
        this.user_choice = 1500000;
        this.cancelTimer = this.cancelTimer.bind(this);
        this.startTimer = this.startTimer.bind(this);
        this.pauseTimer = this.pauseTimer.bind(this);
        this.pauseTimer = this.countdownTime.bind(this);
        this.pauseTimer = this.calculateDisplayTime.bind(this);
    }

    calculateDisplayTime()  {
        let sec_time = "00";
        let sec_temp = Math.floor(this.state.time / 1000);
        let min_time = (Math.floor(sec_temp / 60)).toString();
        if (sec_temp % 60 != 0) {
            sec_time = (Math.floor(sec_temp % 60)).toString();
        }
        let result = {
            "minutes": min_time,
            "seconds": sec_time
        };
        return result;
    }

    countdownTime() {
        console.log("Counting down...");
        let new_time = this.state.time - 1000;
        this.setState({ display : this.calculateDisplayTime, time : new_time });
        if (this.state.time == 0) {
            clearInterval(this.statusID);
            this.status = "default";
            this.state.time = this.user_choice;
        }
    }

    startTimer()    {
        console.log("Starting Timer...");
        if (this.state.time > 0 && (this.status == "default" || this.status == "paused"))   {
            let boundedCountdown = this.countdownTime.bind(this);
            this.status = "running";
            this.statusID = setInterval(boundedCountdown, 1000);
        }
    }

    pauseTimer()    {
        if (this.status == "running")    {
            clearInterval(this.statusID);
            this.status = "paused";
        }
    }

    cancelTimer()   {
        if (window.confirm("Are you sure you want to cancel the current focus session?"))  {
            clearInterval(this.statusID);
            this.status = "default";
            let new_time = this.user_choice;
            this.setState({ display : this.calculateDisplayTime, time : new_time });
        }
    }
}

function Timer()    {
    let timer = new TimerClass();
    timer.state.display = timer.calculateDisplayTime();
    return  (
        <>
            <h2>{timer.state.display.minutes}:{timer.state.display.seconds}</h2>
            <button onClick={timer.startTimer}>Start</button>
        </>
    );
}

export default Timer;