import React from 'react';
import Timer from '../components/Timer';
import generateImage from '../components/temp_generate_img';

function FocusTimer()   {
    return  (
        <>
            <h3>Please choose a focus session length:</h3>
            <Timer />
            <br/>
            <button onClick={generateImage}>Generate Background Image</button>
        </>
    );
}

export default FocusTimer;